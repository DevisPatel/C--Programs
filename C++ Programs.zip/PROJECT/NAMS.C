#include<stdio.h>
#include<conio.h>
#include<math.h>

float f(float x)
{
return ((x*x*x*x)-(4*x*x*x)+(2*x*x)-(10*x)+2);
}
float f1(float x)
{
return ((4*x*x*x)-(12*x*x)+(4*x)-10);
}
float f2(float x)
{
return ((12*x*x)-(24*x)+4);
}
float f3(float x)
{
return ((24*x)-24);
}
float f4(float x)
{
return (24*x);
}

void main()
{
	float a,b;
	clrscr();
	printf("\n \t BUDAN'S  THEORM \n");
	printf("\n enter the value of both interval \n");
	scanf("%f %f",&a,&b);
	printf("\n the given interval for given function is [%f,%f] \n",a,b);

	printf("\n The given function is x^4 - 4*x^3 + 2*x*x - 10*x + 2 \n");
	printf("\n value of function for interval value a is %f \n",f(a));
	printf("\n value of function for interval value b is %f \n",f(b));

	printf("\n The First Derivative of the given function is 4*x^3 - 12*x^2 + 4*x - 10 \n");
	printf("\n value of first derivative for interval value a is %f \n",f1(a));
	printf("\n value of first derivative for interval value b is %f \n",f1(b));

	printf("\n The Second Derivative of the given function is 12*x^2 - 24*x + 4 \n");
	printf("\n value of second derivative for interval value a is %f \n",f2(a));
	printf("\n value of second derivative for interval value b is %f \n",f2(b));

	printf("\n The Third Derivative of the given function is 24*x - 24 \n");
	printf("\n value of third derivative for interval value a is %f \n",f3(a));
	printf("\n value of third derivative for interval value b is %f \n",f3(b));

	printf("\n The Forth Derivative of the given function is 24 \n");
	printf("\n value of forth derivative for interval value a is %f \n",f4(1));
	printf("\n value of forth derivative for interval value b is %f \n",f4(1));


	getch();
}






