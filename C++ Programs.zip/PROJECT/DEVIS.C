#include<stdio.h>
#include<conio.h>
#include<math.h>

void main()
{
	int a,i,n,j,k,l,m,f1,f2,f3;
	char c[4],d[4],e[4],f[4],p,q,r,s;
	clrscr();
	printf("\n \t\t BUDAN'S  THEORM \n");
	printf("\n enter the first part of function \n");
	printf("\n enter the number for multiplication \n");
	scanf("%d",&j);
	for(i=0;i<4;i++)
	{
	scanf("%c",&c);
	}

	printf("\n enter the second part of function \n");
	printf("\n enter the sign you want to write + OR - \n");
	scanf("%c",&p);
	printf("\n enter the number for multiplication \n");
	scanf("%d",&k);

	for(i=0;i<3;i++)
	{
	scanf("%c",&d[i]);
	}

	printf("\n enter the third part of function \n");
	printf("\n enter the sign you want to write + OR - \n");
	scanf("%c",&q);
	printf("\n enter the number for multiplication \n");
	scanf("%d",&l);

	for(i=0;i<2;i++)
	{
	scanf("%c",&e[i]);
	}

	printf("\n enter the forth part of function \n");
	printf("\n enter the sign you want to write + OR - \n");
	scanf("%c",&r);
	printf("\n enter the number for multiplication \n");
	scanf("%d",&m);

	for(i=0;i<1;i++)
	{
	scanf("%c",&f[i]);
	}

	printf("\n enter the forth part of function \n");
	printf("\n enter the sign you want to write + OR - \n");
	scanf("%c",&s);

	printf("\n enter last part of function \n");
	scanf("%d",&a);

	printf("\n THE FINAL FUNCTION IS  %d*%c*%c*%c*%c %c %d*%c*%c*%c %c %d*%c*%c %d*%c %c %d \n",j,c[0],c[1],c[2],c[3],p,k,d[0],d[1],d[2],q,l,e[0],e[1],r,m,f[0],s,a);
       getch();
}





