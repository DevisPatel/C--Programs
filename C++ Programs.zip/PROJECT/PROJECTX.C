#include<stdio.h>
#include<conio.h>
#include<math.h>

int f1(int x)
{
	return ((2*x*x*x)-(3*x*x)+(2*x)-1);
}

int f2(int x)
{
	return ((6*x*x)-(6*x)+2);
}

int f3(int x)
{
	return ((12*x)-6);
}

int f4()
{
return 12;
}
void main()
{
	int i,j,z;
	int a,b;
	clrscr();

	printf("\t\t BUDAN'S THEORM");
	printf("\n enter the interval values \n");
	scanf("\n %d %d",&a,&b);
	printf("\n the given function is 2*x*x*x -3*x*x + 2*x - 1");
	printf("\n First Derivative of the given function is 6*x*x - 6*x + 2");
	printf("\n Second Derivative of the given function is 12*x - 6");
	printf("\n Third Derivative of the given function is 12");

	printf("\n the table of values of the given function at given interval is following \n");
	printf("\n INTRERVAL\tf1(x)\tf2(x)\tf3(x)\tf4(x)\tV(x)\n------------------------------------------------------\n %d\t\t%d\t%d\t%d\t%d\n %d\t\t%d\t%d\t%d\t%d\n",a,f1(a),f2(a),f3(a),f4(a),b,f1(b),f2(b),f3(b),f4(b));

	if(f1(a)>0)
	{
	 if(f2(a)>0)
	 {
	  z=0;
	  }
	 elseif(f2(a)<0)
	 {
	 z++;
	 }
	 else
	 {
	 z=0;
	 }
	}
	getch();
}


