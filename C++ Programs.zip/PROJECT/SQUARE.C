#include<stdio.h>
#include<conio.h>

void main()
{
	int i,j;
	clrscr();
	for(i=0;i<=16;i++)
	{
	 for(j=0;j<=16;j++)
	 {
	  if(i==0 || i==12 || j==0 || j==12 || i==4 || i==8 || j==4 || j==8 || i==16 || j==16)
	  printf(" *");
	  else
	  printf("  ");
	 }
	 printf("\n");
	}
	getch();
}
