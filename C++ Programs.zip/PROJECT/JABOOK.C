#include<stdio.h>
#include<conio.h>

void main()
{
	int i,j,n;
	clrscr();
	printf("\n enter dimension value to construct square \n");
	scanf("%d",&n);
     for(i=0;i<=n;i++)
	{
	 for(j=0;j<=n;j++)
	 {
	  if(i==0 || j==0 || i==n || j==n)
	  printf(" \3");
	  else
	  printf("  ");
	 }
	 printf("\n");
	}

	n=n-1;
	for(i=0;i<=n;i++)
	{
	 for(j=0;j<=n;j++)
	 {
	  if(i==0 || j==0 || i==n || j==n)
	  printf(" \3");
	  else
	  printf("  ");
	 }
	 printf(" \n ");
	}

	getch();
}
