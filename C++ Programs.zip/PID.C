#include<iostream.h>
#include<conio.h>
#include<math.h>
#include<dos.h>

void main()
{
	float p,i,d,k,t,kp,ki,kd,er,per,dt;
	per=0;
	clrscr();

	cout<<endl<<"enter the value of error";
	cin>>k;

	cout<<endl<<"enter the value of Kp , Ki and Kd";
	cin>>kp>>ki>>kd;

	cout<<endl<<"enter the rate of time";
	cin>>dt;

	do
	{
	  er=0-k;
	  p=kp*er;
	  i=ki*((er+per)*dt);
	  d=kd*((er-per)/dt);
	  er=per;
	  t=p+i+d;
	  cout<<endl<<t;

	  sound(100*t);
	  wait(200);
	  if(er=0)
	  exit();
	 }
	getch();
}




