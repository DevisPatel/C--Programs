void main()
{
	int x,y;
	clrscr();
	printf("enter the value for x \n");
	scanf("%d",&x);
	y=x/30;
	x=x%30;
	printf("%d months & %d days \n",y,x);
	getch();
	}