#include<stdio.h>
#include<conio.h>

void main()
{
	int a[3][3],i,j,k,x,y,z;
	float x1,x2,x3;
	clrscr();
	printf("\n GAUSS ELEMINATION METHOD \n");
	printf("\n enter matrix \n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	printf("\n enter the right side values \n");
	scanf("%d %d %d",&x,&y,&z);
	printf("\n the matrix is \n \t%d \t%d \t%d \t%d \n \t%d \t%d \t%d \t%d \n \t%d \t%d \t%d \t%d \n",a[0][0],a[0][1],a[0][2],x,a[1][0],a[1][1],a[1][2],y,a[2][0],a[2][1],a[2][2],z);
	x3=z/a[2][2];
	x2=((y-a[1][2])/a[1][1]);
	x1=((x-a[0][1]-a[0][2])/a[0][0]);
	printf("\n the values of variables using GAUSS ELEMINATION method is x1=%f \n x2=%f \n x3=%f \n",x1,x2,x3);
	getch();
	}





