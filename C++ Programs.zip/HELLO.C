
void main()
{
	printf("hello");
	getch();
}