#include<stdio.h>
#include<conio.h>

	void main()
	{
		char a[10],b[10],c[10];
		clrscr();
		printf("\n enter the values of a and b \n");
		scanf("%c %c",&a,&b);
		c=a+b;
		printf("\n the addition is %c \n",c);
		getch();
	}
