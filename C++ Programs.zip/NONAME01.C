#include<stdio.h>
#include<conio.h>

void main()
{
	int a;
	clrscr();
   //	printf("\n enter number \n");
	printf("%o",a);


	getch();
}