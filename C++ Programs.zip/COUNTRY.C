#include <stdio.h>
#include<conio.h>
#define USA 0

void main()
{
   struct COUNTRY country_info;

   country(USA, &country_info);
   printf("The currency symbol for the USA is: %s \n",
	   country_info.co_curr);
   getch();
}
